<?php
include('index_header.php');
include('location_body.php');
include('index_footer.php');
?>