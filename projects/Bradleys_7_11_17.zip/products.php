<?php
include('index_header.php');
include('products_body.php');
include('index_footer.php');
?>