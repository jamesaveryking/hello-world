<?php
echo '
			  <li><a href="http://bradleys.senior-project-james-king.info/contact.php">Contact</a></li>
			  <li><a href="http://bradleys.senior-project-james-king.info/location.php">Location</a></li>
			  <li><a href="http://bradleys.senior-project-james-king.info/products.php">Products</a></li>
			  <li class="active"><a href="http://bradleys.senior-project-james-king.info/about.php">About</a></li>
		  </ul>
		</div>
	  </div>
	  </div>
	</nav>
	
	<div class="container">
		<div class="well well-lg">
			<div class="well"><p>Bradley\'s Tractor and Service Center</p></div>
			<img src="Kens_Google_Maps.png" class="img-rounded" alt="bradley_storefront" height="40%" width="100%">
			<div class="well">Lorem ipsum dolor <a class="login" href="">s</a>it amet, consectetur adipiscing elit. Ut consectetur libero fringilla magna egestas hendrerit. Mauris lorem nulla, mollis sit amet venenatis id, viverra eget dui. Nam id varius mi, nec lacinia urna. Duis vestibulum mauris magna, eleifend eleifend diam mattis vitae. Donec vitae felis a metus efficitur vestibulum non non magna. Curabitur non venenatis diam. Vestibulum eleifend auctor diam tristique pretium. Cras mattis neque vel aliquet lacinia. Integer ac urna quis est euismod vestibulum in lacinia neque.

Donec sit amet nulla vel lacus bibendum maximus. Donec porttitor leo ac erat rutrum, vel dignissim mauris aliquet. Vestibulum nisi sapien, lacinia ut tincidunt ac, sollicitudin in mi. Nunc ac erat quam. Morbi vel risus vestibulum, rhoncus ante et, dapibus nulla. Sed vehicula turpis quis nisl vestibulum, et gravida arcu dapibus. Phasellus interdum justo eget iaculis mattis. Duis sed accumsan diam. Integer vel ligula ipsum. Ut vel nisl eget nisi gravida aliquet. Cras finibus justo ante, non molestie leo pulvinar vitae. Etiam iaculis, est ac tincidunt interdum, dolor neque consequat erat, sagittis euismod mi neque et turpis.

Ut molestie tortor urna, eget consequat arcu commodo non. Vivamus malesuada dolor nec semper faucibus. Phasellus viverra nec diam nec commodo. Quisque diam velit, consequat at mi in, tempor posuere nunc. Maecenas porttitor efficitur lobortis. Nulla eget egestas ex. Cras non posuere metus. Morbi tristique posuere mattis.

Suspendisse auctor ultricies lectus fringilla tempor. Etiam sagittis magna sed mollis imperdiet. In vestibulum neque augue, ac hendrerit ante finibus quis. Praesent orci mi, placerat nec augue elementum, egestas bibendum leo. Sed venenatis, massa nec tincidunt lobortis, nibh sem congue libero, vitae malesuada neque erat at felis. Etiam auctor odio neque, id mattis turpis pharetra at. Quisque id augue purus. Vivamus et sapien dolor. Curabitur vitae urna ornare, consectetur justo efficitur, tincidunt purus. Morbi hendrerit odio justo, vitae luctus justo tempus at. Praesent mi purus, pellentesque non lobortis at, cursus nec diam. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Ut iaculis nulla id lacus accumsan, et tincidunt neque tristique. Sed sit amet dui gravida, viverra ante vitae, hendrerit erat. Praesent porttitor, odio vitae molestie vulputate, augue nunc fermentum nisi, eu fermentum augue nibh eu dui. Sed fermentum leo id rhoncus mollis.

Sed tincidunt nunc sit amet pulvinar blandit. Donec non felis diam. Aenean iaculis vehicula felis, quis vestibulum lorem eleifend sit amet. Etiam sit amet sodales enim. Sed nec auctor dui. Sed a velit et risus lacinia pulvinar luctus in mauris. Aliquam tristique odio rutrum, dignissim turpis vitae, mattis mauris. Mauris in dictum mi, in facilisis metus. Vestibulum vitae faucibus nulla. Nam aliquet nunc tempor, molestie neque id, mollis mi. Donec vehicula turpis quis mi elementum gravida. Nulla non ex quis odio commodo mollis quis at dolor. Donec ac nulla at velit varius pretium. Morbi nec diam cursus, pulvinar purus sit amet, elementum leo. Maecenas ultrices placerat facilisis. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae;</div>
		</div>
	</div>
';
?>