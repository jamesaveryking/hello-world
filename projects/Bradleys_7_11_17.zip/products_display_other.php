<?php
include('index_header.php');
include('products_display_other_body.php');
include('index_footer.php');
?>