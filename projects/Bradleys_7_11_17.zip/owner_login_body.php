<?php
echo '
			  <li><a href="http://bradleys.senior-project-james-king.info/contact.php">Contact</a></li>
			  <li><a href="http://bradleys.senior-project-james-king.info/location.php">Location</a></li>
			  <li><a href="http://bradleys.senior-project-james-king.info/products.php">Products</a></li>
			  <li><a href="http://bradleys.senior-project-james-king.info/about.php">About</a></li>
		  </ul>
		</div>
	  </div>
	  </div>
	</nav>
	
	<div class="container">
		<div class="well well-lg">
			<form>
				<div class="form-group">
					<label for="login_email">Login ID:</label>
					<input type="text" class="form-control" id="login_email">
				</div>
				<div class="form-group">
					<label for="login_password">Password:</label>
					<input type="text" class="form-control" id="login_password">
				</div>
				<br><br>
				<button type="submit" class="btn btn-default">Login</button>
			</form>
		</div>
	</div>
';
?>