<?php
echo'<div class="container">
		<div class="well well-lg">
			<div class="contact_information">
				<div class="well">Email: bradleysservicecenter357@mail.com<br>Address: 5665 Joe Frank Harris Parkway Adairsville Georgia<br>Phone: (770)769-4723</div>			
			</div>
		</div>
	</div>
</body>
</html>';
?>