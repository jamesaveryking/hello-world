<?php
echo '
			  <li><a href="http://bradleys.senior-project-james-king.info/contact.php">Contact</a></li>
			  <li><a href="http://bradleys.senior-project-james-king.info/location.php">Location</a></li>
			  <li class="active"><a href="http://bradleys.senior-project-james-king.info/products.php">Products</a></li>
			  <li><a href="http://bradleys.senior-project-james-king.info/about.php">About</a></li>
		  </ul>
		</div>
	  </div>
	  </div>
	</nav>
	<div class="container">    
	  <div class="row">
		<div class="col-sm-3">
		  <div class="panel panel-primary">
			<div class="panel-heading">10 Series</div>
			<div class="panel-body">
				<img src="https://placehold.it/150x80?text=IMAGE" class="img-responsive" style="width:100%" alt="Image"><br>
				<center><a href="http://bradleys.senior-project-james-king.info/products_display_individual" class="btn btn-primary btn-lg">Set Viewing Appointment</a></center>
			</div>
		  </div>
		</div>
		<div class="col-sm-3">
		  <div class="panel panel-primary">
			<div class="panel-heading">10 Series</div>
			<div class="panel-body">
				<img src="https://placehold.it/150x80?text=IMAGE" class="img-responsive" style="width:100%" alt="Image"><br>
				<center><a href="http://bradleys.senior-project-james-king.info/products_display_individual" class="btn btn-primary btn-lg">Set Viewing Appointment</a></center>
			</div>
		  </div>
		</div>
		<div class="col-sm-3">
		  <div class="panel panel-primary">
			<div class="panel-heading">10 Series</div>
			<div class="panel-body">
				<img src="https://placehold.it/150x80?text=IMAGE" class="img-responsive" style="width:100%" alt="Image"><br>
				<center><a href="http://bradleys.senior-project-james-king.info/products_display_individual" class="btn btn-primary btn-lg">Set Viewing Appointment</a></center>
			</div>
		  </div>
		</div>
		<div class="col-sm-3">
		  <div class="panel panel-primary">
			<div class="panel-heading">10 Series</div>
			<div class="panel-body">
				<img src="https://placehold.it/150x80?text=IMAGE" class="img-responsive" style="width:100%" alt="Image"><br>
				<center><a href="http://bradleys.senior-project-james-king.info/products_display_individual" class="btn btn-primary btn-lg">Set Viewing Appointment</a></center>
			</div>
		  </div>
		</div>
	  </div>
	  <div class="row">
		<div class="col-sm-3">
		  <div class="panel panel-primary">
			<div class="panel-heading">10 Series</div>
			<div class="panel-body">
				<img src="https://placehold.it/150x80?text=IMAGE" class="img-responsive" style="width:100%" alt="Image"><br>
				<center><a href="http://bradleys.senior-project-james-king.info/products_display_individual" class="btn btn-primary btn-lg">Set Viewing Appointment</a></center>
			</div>
		  </div>
		</div>
		<div class="col-sm-3">
		  <div class="panel panel-primary">
			<div class="panel-heading">10 Series</div>
			<div class="panel-body">
				<img src="https://placehold.it/150x80?text=IMAGE" class="img-responsive" style="width:100%" alt="Image"><br>
				<center><a href="http://bradleys.senior-project-james-king.info/products_display_individual" class="btn btn-primary btn-lg">Set Viewing Appointment</a></center>
			</div>
		  </div>
		</div>
		<div class="col-sm-3">
		  <div class="panel panel-primary">
			<div class="panel-heading">10 Series</div>
			<div class="panel-body">
				<img src="https://placehold.it/150x80?text=IMAGE" class="img-responsive" style="width:100%" alt="Image"><br>
				<center><a href="http://bradleys.senior-project-james-king.info/products_display_individual" class="btn btn-primary btn-lg">Set Viewing Appointment</a></center>
			</div>
		  </div>
		</div>
		<div class="col-sm-3">
		  <div class="panel panel-primary">
			<div class="panel-heading">10 Series</div>
			<div class="panel-body">
				<img src="https://placehold.it/150x80?text=IMAGE" class="img-responsive" style="width:100%" alt="Image"><br>
				<center><a href="http://bradleys.senior-project-james-king.info/products_display_individual" class="btn btn-primary btn-lg">Set Viewing Appointment</a></center>
			</div>
		  </div>
		</div>
	  </div>
	  <div class="row">
		<div class="col-sm-3">
		  <div class="panel panel-primary">
			<div class="panel-heading">10 Series</div>
			<div class="panel-body">
				<img src="https://placehold.it/150x80?text=IMAGE" class="img-responsive" style="width:100%" alt="Image"><br>
				<center><a href="http://bradleys.senior-project-james-king.info/products_display_individual" class="btn btn-primary btn-lg">Set Viewing Appointment</a></center>
			</div>
		  </div>
		</div>
		<div class="col-sm-3">
		  <div class="panel panel-primary">
			<div class="panel-heading">10 Series</div>
			<div class="panel-body">
				<img src="https://placehold.it/150x80?text=IMAGE" class="img-responsive" style="width:100%" alt="Image"><br>
				<center><a href="http://bradleys.senior-project-james-king.info/products_display_individual" class="btn btn-primary btn-lg">Set Viewing Appointment</a></center>
			</div>
		  </div>
		</div>
		<div class="col-sm-3">
		  <div class="panel panel-primary">
			<div class="panel-heading">10 Series</div>
			<div class="panel-body">
				<img src="https://placehold.it/150x80?text=IMAGE" class="img-responsive" style="width:100%" alt="Image"><br>
				<center><a href="http://bradleys.senior-project-james-king.info/products_display_individual" class="btn btn-primary btn-lg">Set Viewing Appointment</a></center>
			</div>
		  </div>
		</div>
		<div class="col-sm-3">
		  <div class="panel panel-primary">
			<div class="panel-heading">10 Series</div>
			<div class="panel-body">
				<img src="https://placehold.it/150x80?text=IMAGE" class="img-responsive" style="width:100%" alt="Image"><br>
				<center><a href="http://bradleys.senior-project-james-king.info/products_display_individual" class="btn btn-primary btn-lg">Set Viewing Appointment</a></center>
			</div>
		  </div>
		</div>
	  </div>
	  <div class="row">
		<div class="col-sm-6">
		  <div class="panel panel-primary">
			<div class="panel-heading">10 Series</div>
			<div class="panel-body">
				<img src="https://placehold.it/150x80?text=IMAGE" class="img-responsive" style="width:100%" alt="Image"><br>
				<center><a href="http://bradleys.senior-project-james-king.info/products_display_individual" class="btn btn-primary btn-lg">Set Viewing Appointment</a></center>
			</div>
		  </div>
		</div>
		<div class="col-sm-6">
		  <div class="panel panel-primary">
			<div class="panel-heading">10 Series</div>
			<div class="panel-body">
				<img src="https://placehold.it/150x80?text=IMAGE" class="img-responsive" style="width:100%" alt="Image"><br>
				<center><a href="http://bradleys.senior-project-james-king.info/products_display_individual" class="btn btn-primary btn-lg">Set Viewing Appointment</a></center>
			</div>
		  </div>
		</div>
	  </div>
	</div><br>

	';
?>