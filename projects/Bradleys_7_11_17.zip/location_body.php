<?php
echo '
			  <li><a href="http://bradleys.senior-project-james-king.info/contact.php">Contact</a></li>
			  <li class="active"><a href="http://bradleys.senior-project-james-king.info/location.php">Location</a></li>
			  <li><a href="http://bradleys.senior-project-james-king.info/products.php">Products</a></li>
			  <li><a href="http://bradleys.senior-project-james-king.info/about.php">About</a></li>
		  </ul>
		</div>
	  </div>
	  </div>
	</nav>
	
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="well well-lg">
					<div class="well"><p>Google Maps Plugin</p></div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<div class="well well-lg">
					<div class="well"><p>Potential location coordination using cookies?</p></div>
				</div>
			</div>
		</div>
	</div>
';
?>