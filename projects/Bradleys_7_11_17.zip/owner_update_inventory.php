<?php
include('index_header.php');
include('owner_update_inventory_body.php');
include('index_footer.php');
?>